<?php  
	$username = echo "TEST";
?>